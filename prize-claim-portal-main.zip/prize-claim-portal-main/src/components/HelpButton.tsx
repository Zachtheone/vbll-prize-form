import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, X } from "lucide-react";

const HelpButton = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Help Button */}
      <motion.div
        className="fixed top-4 right-4 z-50 flex flex-col items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <motion.button
          onClick={() => setIsOpen(true)}
          className="p-3 rounded-xl glass-card neon-border cursor-pointer"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <BookOpen className="w-6 h-6 text-primary" />
        </motion.button>
        <span className="mt-1 text-xs text-primary font-semibold animate-pulse">
          Click me!
        </span>
      </motion.div>

      {/* Help Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
            />

            {/* Modal */}
            <motion.div
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-lg mx-4 glass-card neon-border rounded-2xl p-6"
              initial={{ opacity: 0, scale: 0.8, y: -50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -50 }}
              transition={{ type: "spring", damping: 20 }}
            >
              {/* Close Button */}
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 p-2 rounded-lg btn-outline-neon"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Title */}
              <h2 className="text-xl font-bold neon-text mb-4">
                How to Submit Your Prize
              </h2>

              {/* Content */}
              <div className="space-y-4 text-foreground/90 text-sm">
                <div className="space-y-2">
                  <h3 className="text-primary font-semibold">1. Player ID</h3>
                  <p className="text-muted-foreground">
                    Enter your unique VBLL player ID (e.g., B-101-29)
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-primary font-semibold">2. Discord Username</h3>
                  <p className="text-muted-foreground">
                    Enter your Discord username with @ (e.g., @papa apeks)
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-primary font-semibold">3. Item Won</h3>
                  <p className="text-muted-foreground">
                    Select the prize item you won from the dropdown menu
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-primary font-semibold">4. Discord Message Link</h3>
                  <p className="text-muted-foreground">
                    Right-click the winning announcement message in Discord → "Copy Message Link" and paste it here
                  </p>
                </div>

                <div className="mt-6 p-3 rounded-lg bg-primary/10 border border-primary/30">
                  <p className="text-primary text-xs">
                    💡 <strong>Tip:</strong> Make sure your Discord message link starts with "https://discord.com/channels/"
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default HelpButton;
