import { motion } from "framer-motion";

interface LogoLandingProps {
  onLogoClick: () => void;
  isExiting: boolean;
}

const LogoLanding = ({ onLogoClick, isExiting }: LogoLandingProps) => {
  return (
    <motion.div
      className="flex flex-col items-center cursor-pointer z-10"
      onClick={onLogoClick}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={isExiting ? { opacity: 0, y: -50, scale: 0.9 } : { opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      {/* Glow effect behind logo */}
      <div className="absolute w-[420px] h-[520px] rounded-3xl bg-primary/15 animate-glow-pulse" />
      
      {/* Logo container */}
      <motion.div
        className="relative"
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      >
        <img
          src="https://i.imgur.com/x9a5rrp.png"
          alt="VBLL Logo"
          className="w-56 rounded-2xl neon-border"
        />
      </motion.div>

      {/* Click prompt */}
      <motion.p
        className="mt-4 text-primary animate-shimmer text-sm tracking-wider"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        Click the logo to access the form
      </motion.p>
    </motion.div>
  );
};

export default LogoLanding;
