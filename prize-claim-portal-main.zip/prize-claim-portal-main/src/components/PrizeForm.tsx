import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, CheckCircle, Loader2, ExternalLink } from "lucide-react";

interface PrizeFormProps {
  onBack: () => void;
}

const WEBHOOK_URL = "https://discord.com/api/webhooks/1449604098251816980/m_mbuU1CNh9nPGJAoQYA6AcrViRNbYQaYeVYAKNUH_Go0s2e8Fj1H99tT2fdEM7zTB5O";

const ITEMS = [
  "VBLL Blue & White Hat",
  "Vbll Boots Blue",
  "Vbll Blue & White Mask",
  "VBLL Goggles",
  "Credits",
  "Scrim Points",
];

const PrizeForm = ({ onBack }: PrizeFormProps) => {
  const [playerId, setPlayerId] = useState("");
  const [discordUser, setDiscordUser] = useState("");
  const [itemWon, setItemWon] = useState("");
  const [messageLink, setMessageLink] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState("");

  const formatDiscordUser = (value: string) => {
    const trimmed = value.trim();
    return trimmed.startsWith("@") ? trimmed : `@${trimmed}`;
  };

  const getPreviewContent = () => {
    if (!playerId || !discordUser || !itemWon || !messageLink) return null;
    const discordName = formatDiscordUser(discordUser);
    return `${playerId.trim()} | ${discordName} | ${itemWon}\n+ your message link`;
  };

  const validateForm = () => {
    if (!playerId.trim()) {
      setError("Please enter your Player ID");
      return false;
    }
    if (!discordUser.trim()) {
      setError("Please enter your Discord username");
      return false;
    }
    if (!itemWon) {
      setError("Please select an item");
      return false;
    }
    if (!messageLink.trim().startsWith("https://discord.com/channels/")) {
      setError("Please enter a valid Discord message link");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!validateForm()) return;

    const discordName = formatDiscordUser(discordUser);
    const content = `${playerId.trim()} | ${discordName} | ${itemWon}\n${messageLink.trim()}`;

    if (!window.confirm(`Are you sure you want to submit:\n\n${content}`)) return;

    setIsSubmitting(true);

    try {
      const response = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });

      if (!response.ok) throw new Error("Failed to submit");

      setShowSuccess(true);
      setPlayerId("");
      setDiscordUser("");
      setItemWon("");
      setMessageLink("");

      setTimeout(() => setShowSuccess(false), 4000);
    } catch {
      setError("Submission failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const preview = getPreviewContent();

  return (
    <motion.div
      className="glass-card neon-border rounded-2xl p-8 w-full max-w-md mx-4"
      initial={{ opacity: 0, y: -100, scale: 0.8 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -50, scale: 0.9 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <h1 className="text-2xl font-bold neon-text text-center mb-6 tracking-wider">
        VBLL Prize Submission
      </h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Player ID */}
        <input
          type="text"
          value={playerId}
          onChange={(e) => setPlayerId(e.target.value)}
          placeholder="B-101-29"
          className="w-full px-4 py-3 rounded-lg input-glow border-none outline-none"
        />

        {/* Discord Username */}
        <input
          type="text"
          value={discordUser}
          onChange={(e) => setDiscordUser(e.target.value)}
          placeholder="@papa apeks"
          className="w-full px-4 py-3 rounded-lg input-glow border-none outline-none"
        />

        {/* Item Won Select */}
        <select
          value={itemWon}
          onChange={(e) => setItemWon(e.target.value)}
          className="w-full px-4 py-3 rounded-lg input-glow border border-primary bg-card cursor-pointer outline-none"
        >
          <option value="" disabled>
            Item Won
          </option>
          {ITEMS.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>

        {/* Message Link */}
        <input
          type="url"
          value={messageLink}
          onChange={(e) => setMessageLink(e.target.value)}
          placeholder="Discord message link"
          className="w-full px-4 py-3 rounded-lg input-glow border-none outline-none"
        />

        {/* Preview Box */}
        <AnimatePresence>
          {preview && (
            <motion.div
              className="preview-box text-sm text-primary whitespace-pre-wrap break-words max-h-32 overflow-y-auto"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              {preview}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Error Message */}
        <AnimatePresence>
          {error && (
            <motion.p
              className="text-destructive text-sm text-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3 rounded-lg btn-neon disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Submitting...
            </>
          ) : (
            "Submit"
          )}
        </button>

        {/* Back Button */}
        <button
          type="button"
          onClick={onBack}
          className="w-full py-3 rounded-lg btn-outline-neon flex items-center justify-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
      </form>

      {/* Success Message */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            className="mt-4 flex items-center justify-center gap-2 success-text"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
          >
            <CheckCircle className="w-5 h-5" />
            <span>Submitted successfully!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Discord Link */}
      <a
        href="https://discord.gg/vbll"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4 py-3 rounded-lg discord-gradient text-secondary-foreground font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
      >
        Join VBLL Discord
        <ExternalLink className="w-4 h-4" />
      </a>
    </motion.div>
  );
};

export default PrizeForm;
