import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import LogoLanding from "@/components/LogoLanding";
import PrizeForm from "@/components/PrizeForm";
import HelpButton from "@/components/HelpButton";

const Index = () => {
  const [showForm, setShowForm] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const handleLogoClick = () => {
    setIsExiting(true);
    setTimeout(() => {
      setShowForm(true);
      setIsExiting(false);
    }, 600);
  };

  const handleBack = () => {
    setShowForm(false);
  };

  return (
    <>
      <HelpButton />
    <main className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Floating particles/stars effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `shimmer ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        {!showForm ? (
          <LogoLanding
            key="logo"
            onLogoClick={handleLogoClick}
            isExiting={isExiting}
          />
        ) : (
          <PrizeForm key="form" onBack={handleBack} />
        )}
      </AnimatePresence>
    </main>
    </>
  );
};

export default Index;
